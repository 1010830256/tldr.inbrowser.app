# mkdir

> একটি নির্দেশিকা তৈরি করে।
> আরও তথ্য পাবেন: <https://learn.microsoft.com/windows-server/administration/windows-commands/mkdir>।

- একটি নির্দেশিকা তৈরি করুন:

`mkdir {{নির্দেশিকা\এর\পথ}}`

- পুনরাবৃত্তি হিসেবে একটি নেস্টেড নির্দেশিকা ট্রি তৈরি করুন:

`mkdir {{উপনির্দেশিকা\এর\পথ}}`
