# screencap

> একটি মোবাইল ডিসপ্লের স্ক্রিনশট নিন।
> এই কমান্ডটি শুধুমাত্র `adb shell` এর মাধ্যমে ব্যবহার করা যেতে পারে।
> আরও তথ্য পাবেন: <https://developer.android.com/tools/adb#screencap>।

- একটি স্ক্রিনশট নিন:

`screencap {{ফাইলের/পথ}}`
