# fossil new

> Ova komanda je pseudonim za  `fossil init`.
> Više informacija: <https://fossil-scm.org/home/help/new>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr fossil-init`
