# fossil ci

> Ova komanda je pseudonim za  `fossil commit`.
> Više informacija: <https://fossil-scm.org/home/help/commit>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr fossil-commit`
