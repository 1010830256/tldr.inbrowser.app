# view

> Read-only verzija `vim`.
> Ovo je ekvivalent za `vim -R`.
> Više informacija: <https://www.vim.org>.

- Otvori datoteku:

`view {{datoteka}}`
