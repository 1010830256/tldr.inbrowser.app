# clang-cpp

> Ova komanda je pseudonim za `clang++`.

- Pregledaj dokumentaciju za izvornu komandu:

`tldr clang++`
