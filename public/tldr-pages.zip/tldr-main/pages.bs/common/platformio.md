# platformio

> Ova komanda je pseudonim za `pio`.
> Više informacija: <https://docs.platformio.org/en/latest/core/userguide/>.

- Pregledaj dokumentaciju za izvornu komandu:

`tldr pio`
