# cuninst

> Ova komanda je pseudonim za `choco uninstall`.
> Više informacija: <https://docs.chocolatey.org/en-us/choco/commands/uninstall>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr choco uninstall`
