# curl

> Ova komanda je pseudonim za `curl -p common`.
> Više informacija: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/invoke-webrequest>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr curl -p common`
