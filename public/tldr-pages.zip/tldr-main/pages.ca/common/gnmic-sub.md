# gnmic sub

> Aquest comandament és un àlies de `gnmic subscribe`.
> Més informació: <https://gnmic.kmrd.dev/cmd/subscribe>.

- Veure documentació pel comandament original:

`tldr gnmic subscribe`
