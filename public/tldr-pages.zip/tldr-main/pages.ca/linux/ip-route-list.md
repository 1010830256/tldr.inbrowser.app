# ip route list

> Aquest comandament és un àlies de  `ip route show`.

- Veure documentació pel comandament original:

`tldr ip-route-show`
