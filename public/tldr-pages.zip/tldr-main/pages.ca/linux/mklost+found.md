# mklost+found

> Crea un directori lost+found.
> Més informació: <https://manned.org/mklost+found>.

- Crea un directori `lost+found` en el directori actual:

`mklost+found`
