# newgrp

> Canvia el grup primari de pertinència.
> Més informació: <https://manned.org/newgrp>.

- Canvia el grup primari de pertinència del usuari:

`newgrp {{nom_grup}}`

- Restableix el grup primari de pertinència al grup per defecte del usuari `/etc/passwd`:

`newgrp`
