# conky

> Monitor de sistema lleuger per X.
> Més informació: <https://github.com/brndnmtthws/conky>.

- Executa amb la configuració per defecte:

`conky`

- Crea una nova configuració per defecte:

`conky -C > ~/.conkyrc`

- Executa conky amb un arxiu de configuració concret:

`conky -c {{ruta/a/la/configuració}}`

- Executa en segon pla (daemonize):

`conky -d`

- Posiciona conky en l'escriptori:

`conky -a {{top|bottom|middle}}_{{left|right|middle}}`

- Pausa de 5 segons al iniciar abans d'executar-lo:

`conky -p {{5}}`
