# cpuid

> Mostra informació detallada sobre totes les CPUs.
> Més informació: <http://etallen.com/cpuid.html>.

- Mostra informació de totes les CPUs:

`cpuid`

- Mostra informació només per la CPU actual:

`cpuid -1`

- Mostra informació hexadecimal en brut sense decodificar:

`cpuid -r`
