# pkgrm

> Elimina un paquet d'un sistema CRUX.
> Més informació: <https://docs.oracle.com/cd/E88353_01/html/E72487/pkgrm-8.html>.

- Elimina un paquet instal·lat:

`pkgrm {{nom_del_paquet}}`
