# i7z

> Eina d'informes en temps real per CPUs Intel (només i3, i5 i i7).
> Més informació: <https://manned.org/i7z>.

- Inicia i7z (cal executar amb permisos de root):

`sudo i7z`
