# a2dismod

> Desactiva un mòdul Apache en sistemes operatius basats en Debian.
> Més informació: <https://manpages.debian.org/latest/apache2/a2dismod.8.en.html>.

- Desactiva un mòdul:

`sudo a2dismod {{mòdul}}`

- No mostrius missatges informatius:

`sudo a2dismod --quiet {{mòdul}}`
