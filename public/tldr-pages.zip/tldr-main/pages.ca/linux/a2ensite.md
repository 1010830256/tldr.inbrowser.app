# a2ensite

> Activa un host virtual d'Apache en sistemes operatius basats en Debian.
> Més informació: <https://manpages.debian.org/latest/apache2/a2ensite.8.en.html>.

- Activa un host virtual:

`sudo a2ensite {{host_virtual}}`

- No mostris missatges informatius:

`sudo a2ensite --quiet {{host_virtual}}`
