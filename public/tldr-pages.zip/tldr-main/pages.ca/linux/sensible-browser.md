# sensible-browser

> Obre el navegador predeterminat.
> Més informació: <https://manned.org/sensible-browser>.

- Obre una nova finestra del navegador predeterminat:

`sensible-browser`

- Obre una URL en el navegador predeterminat:

`sensible-browser {{url}}`
