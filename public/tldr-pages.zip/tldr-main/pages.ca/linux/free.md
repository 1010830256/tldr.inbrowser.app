# free

> Mostra la quantitat de memòria lliure i utilitzada en el sistema.
> Més informació: <https://manned.org/free>.

- Mostra la memòria del sistema:

`free`

- Mostra la memòria del sistema en Bytes/KB/MB/GB:

`free -{{b|k|m|g}}`

- Mostra la memòria del sistema en unitats llegibles per humans:

`free -h`

- Actualitza la sortida cada 2 segons:

`free -s {{2}}`
