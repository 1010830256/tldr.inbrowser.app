# pwsh where

> Aquest comandament és un àlies de `Where-Object`.
> Més informació: <https://learn.microsoft.com/powershell/module/microsoft.powershell.core/where-object>.

- Veure documentació pel comandament original:

`tldr Where-Object`
