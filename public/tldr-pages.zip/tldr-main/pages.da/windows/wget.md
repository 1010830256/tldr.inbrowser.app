# wget

> Denne kommando er et alias af `wget -p common`.
> Mere information: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/invoke-webrequest>.

- Se dokumentation for den oprindelige kommando:

`tldr wget -p common`
