# sls

> Denne kommando er et alias af `Select-String`.
> Mere information: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/select-string>.

- Se dokumentation for den oprindelige kommando:

`tldr select-string`
