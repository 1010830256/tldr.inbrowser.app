# wget

> هذا الأمر هو اسم مستعار لـ `wget -p common`.
> لمزيد من التفاصيل: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/invoke-webrequest>.

- إعرض التوثيقات للأمر الأصلي:

`tldr wget -p common`
