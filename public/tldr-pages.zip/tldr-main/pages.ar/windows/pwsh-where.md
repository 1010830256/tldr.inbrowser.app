# pwsh where

> هذا الأمر هو اسم مستعار لـ `Where-Object`.
> لمزيد من التفاصيل: <https://learn.microsoft.com/powershell/module/microsoft.powershell.core/where-object>.

- إعرض التوثيقات للأمر الأصلي:

`tldr Where-Object`
