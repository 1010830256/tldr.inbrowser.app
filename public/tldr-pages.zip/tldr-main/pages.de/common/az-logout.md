# az logout

> Von Azure-Abonnements abmelden.
> Teil von `azure-cli` (auch bekannt als `az`).
> Weitere Informationen: <https://learn.microsoft.com/cli/azure/reference-index#az_logout>.

- Melde das aktuelle aktive Konto ab:

`az logout`

- Melde einen spezifischen Benutzernamen ab:

`az logout --username {{alias@somedomain.com}}`
