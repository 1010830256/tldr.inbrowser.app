# bundler

> Dieser Befehl ist ein Alias von `bundle`.
> Weitere Informationen: <https://bundler.io/man/bundle.1.html>.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr bundle`
