# git show-unmerged-branches

> Gibt alle Branches aus, welche noch nicht in die aktuelle HEAD-Datei gemerged wurden.
> Weitere Informationen: <https://github.com/tj/git-extras/blob/master/Commands.md#git-show-unmerged-branches>.

- Gib alle Branches aus, die noch nicht in die aktuelle HEAD-Datei gemerged wurden:

`git show-unmerged-branches`
