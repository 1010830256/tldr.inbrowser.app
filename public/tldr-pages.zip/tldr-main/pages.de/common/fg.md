# fg

> Bringt Prozesse in den Vordergrund.
> Weitere Informationen: <https://manned.org/fg>.

- Bringe zuletzt suspendierten Prozess in den Vordergrund:

`fg`

- Bringe einen bestimmten Prozess in den Vordergrund:

`fg %{{prozess_id}}`
