# ClamAV

> Dieser Befehl ist ein Alias von `clamdscan`.
> Weitere Informationen: <https://www.clamav.net>.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr clamdscan`
