# screencap

> Nimmt ein Bildschirmfoto von einem Handy-Display auf.
> Dieser Befehl kann nur über die 'adb shell' benutzt werden.
> Weitere Informationen: <https://developer.android.com/tools/adb#screencap>.

- Nehme ein Bildschirmfoto auf:

`screencap {{pfad/zu/datei}}`
