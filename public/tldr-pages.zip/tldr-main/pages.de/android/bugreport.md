# bugreport

> Zeige Android-Fehlerberichte.
> Dieser Befehl kann nur mit `adb shell` verwendet werden.
> Weitere Informationen: <https://cs.android.com/android/platform/superproject/+/main:frameworks/native/cmds/bugreport>.

- Zeige einen vollständigen Fehlerbericht eines Androidgeräts an:

`bugreport`
